 import brgr1  from "./bearsteak/group/1.png";
 import brgr2  from "./bearsteak/group/2.png";
 import brgr3  from "./bearsteak/group/3.png";
 import brgr4  from "./bearsteak/group/4.png";
 import brgr5  from "./bearsteak/group/5.png";
 import brgr6  from "./bearsteak/group/6.png";
 import brgr7  from "./bearsteak/group/7.png";
 import brgr8  from "./bearsteak/group/8.png";
 import brgr9  from "./bearsteak/group/9.png";
 import brgr10 from "./bearsteak/group/10.png";
 import avatar from "./avatar.png";

 export {brgr1, brgr2, brgr3, brgr4, brgr5, brgr6, brgr7, brgr8, brgr9, brgr10, avatar}
