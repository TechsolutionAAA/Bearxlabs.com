import React from 'react'
import CommingSoon from '../components/CommingSoon'

function Marketplace() {
  return (
    <>
        <CommingSoon />
    </>
  )
}

export default Marketplace