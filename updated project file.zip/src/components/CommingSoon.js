import React from 'react'
import { Container } from 'react-bootstrap'

function CommingSoon() {
  return (
    <Container>
        <div className='d-flex justify-content-center align-items-center vh-100'>
            <h1 className='text-white'>Coming Soon!</h1>
        </div>
    </Container>
  )
}

export default CommingSoon