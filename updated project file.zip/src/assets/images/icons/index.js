import piIstagram from './instagram.png';
import piTwitter from './twitter.png';
import piLooksrare from './looksrare.png';
import piMedium from './medium.png';
import piOpensea from './opensea.png';
import piDiscord from './discord.png';

export {piIstagram, piTwitter, piLooksrare, piMedium, piOpensea, piDiscord}