import React from 'react';
import Banner from '../Banner';

const RootHero = () => {
  return (
    <Banner title="What Is Root?"/>
  )
}

export default RootHero