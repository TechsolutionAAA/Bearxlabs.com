import React from 'react'
import { Container } from 'react-bootstrap'

const ShopHero = () => {
  return (
    <div className='commonbanner'>
        <Container>
            <div className='aboutHero__heading'>
                <h1>shop</h1>
            </div>
        </Container>
    </div>
  )
}

export default ShopHero