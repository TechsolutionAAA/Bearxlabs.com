import React from 'react'
import Banner from '../components/Banner'

function LPTokenStaking() {
  return (
    <>
        <Banner title="LP Token Staking" />
        <div className="about__details">
        <p style={{ color: "yellow", fontSize: "50px" }}>COMING SOON</p>
      </div>
    </>
  )
}

export default LPTokenStaking